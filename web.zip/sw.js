const CACHE="rangmanch-v50-73-shell";
const V="?v=573";
const SHELL=["/","/index.html","/.well-known/assetlinks.json","/privacy-policy.html","/admin.html","/admin/index.html","/privacy-policy/index.html","/manifest.webmanifest","/icon-192.png?v=563","/icon-512.png?v=563","/icon-splash-192.png?v=563","/icon-splash-512.png?v=563","/icon-192-maskable.png?v=563","/icon-512-maskable.png?v=563",
 "/assets/tailwind.css"+V,"/assets/fa/css/all.min.css"+V,"/assets/fa/webfonts/fa-solid-900.woff2","/assets/fa/webfonts/fa-regular-400.woff2","/assets/fa/webfonts/fa-brands-400.woff2",
 "/shortcut-icons/home-192.png","/shortcut-icons/shorts-192.png","/shortcut-icons/library-192.png","/shortcut-icons/studio-192.png","/shortcut-icons/upload-192.png"];
const STATIC_HOSTS=new Set(["cdnjs.cloudflare.com","fonts.googleapis.com","fonts.gstatic.com","cdn.jsdelivr.net"]);
const EXTERNAL_SHELL=[
 "https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap",
 "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2",
 "https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"
];
const OFFLINE="<!doctype html><meta name=viewport content=width=device-width,initial-scale=1><title>Rang Manch</title><main style=\"font:16px sans-serif;padding:24px;text-align:center\"><h2>Rang Manch India</h2><p>You are offline. Reconnect to the internet once to load the latest app, then try again.</p></main>";
const ASSET_RE=/\.(?:css|js|png|jpg|jpeg|webp|svg|webmanifest|woff2?)$/i;
self.addEventListener("install",e=>{e.waitUntil((async()=>{const c=await caches.open(CACHE);
 await Promise.all(SHELL.map(async url=>{try{const r=await fetch(url,{cache:"reload"});if(r.ok)await c.put(url,r)}catch(_){}}));
 await Promise.all(EXTERNAL_SHELL.map(async url=>{try{const req=new Request(url,{mode:"cors",credentials:"omit",cache:"reload"});const r=await fetch(req);if(r.ok&&r.type!=="opaque")await c.put(req,r)}catch(_){}}));
 await self.skipWaiting()})())});
self.addEventListener("activate",e=>{e.waitUntil((async()=>{
 const keys=await caches.keys();await Promise.all(keys.filter(k=>k!==CACHE&&k.startsWith("rangmanch-")).map(k=>caches.delete(k)));
 try{if(self.registration.navigationPreload)await self.registration.navigationPreload.enable()}catch(_){}
 await self.clients.claim()})())});
self.addEventListener("message",e=>{if(e.data&&e.data.type==="SKIP_WAITING")self.skipWaiting()});
function timeout(ms){return new Promise((_,rej)=>setTimeout(()=>rej(new Error("timeout")),ms))}
self.addEventListener("fetch",e=>{const r=e.request;if(r.method!=="GET")return;const u=new URL(r.url);
 // Cross-origin: only known static hosts, cache-first (versioned/immutable files).
 if(u.origin!==location.origin){if(!STATIC_HOSTS.has(u.hostname))return;if(!["script","style","font","image"].includes(r.destination))return;
  e.respondWith((async()=>{const c=await caches.open(CACHE),hit=await c.match(r);if(hit)return hit;try{const res=await fetch(r);if(res.ok&&res.type!=="opaque")c.put(r,res.clone());return res}catch(_){return hit||Response.error()}})());return;}
 // Never cache Supabase REST/auth/function traffic or uploaded video files as API data.
 if(u.pathname.startsWith("/rest/")||u.pathname.startsWith("/auth/")||u.pathname.startsWith("/functions/")||u.pathname.startsWith("/storage/"))return;
 // Pages: network-first (3 s) so updates arrive, then cache, then offline page.
 if(r.mode==="navigate"){e.respondWith((async()=>{
  try{const pre=e.preloadResponse?await e.preloadResponse:null;
   const res=pre||await Promise.race([fetch(r),timeout(3000)]);
   if(res&&res.ok){const c=await caches.open(CACHE);c.put(r,res.clone())}
   return res}
  catch(_){return (await caches.match(r))||(await caches.match(u.pathname,{ignoreSearch:true}))||(await caches.match("/index.html",{ignoreSearch:true}))||(await caches.match("/",{ignoreSearch:true}))||new Response(OFFLINE,{headers:{"Content-Type":"text/html; charset=utf-8"}})}
 })());return;}
 // Same-origin static files: instant from cache, refreshed in the background.
 e.respondWith((async()=>{const c=await caches.open(CACHE);const hit=await c.match(r);
  const net=fetch(r).then(res=>{if(res.ok&&ASSET_RE.test(u.pathname))c.put(r,res.clone());return res}).catch(()=>null);
  if(hit){e.waitUntil(net);return hit}
  return (await net)||Response.error()})());
});

// V50.64: retained Web Push receiver (existing behavior). A server must send Web Push payloads to a saved subscription.
self.addEventListener("push", event => {
  let payload = {};
  try { payload = event.data ? event.data.json() : {}; } catch (_) { payload = { body: event.data ? event.data.text() : "You have a new update." }; }
  const title = String(payload.title || "Rang Manch India").slice(0, 120);
  const body = String(payload.body || payload.message || "You have a new notification.").slice(0, 300);
  const target = typeof payload.url === "string" && payload.url.startsWith("/") ? payload.url : "/";
  event.waitUntil(self.registration.showNotification(title, {
    body, icon: "/icon-192.png?v=563", badge: "/icon-192.png?v=563",
    tag: String(payload.tag || "rangmanch-push").slice(0, 100),
    data: { url: target }, renotify: false
  }));
});
self.addEventListener("notificationclick", event => {
  event.notification.close();
  const target = event.notification.data && typeof event.notification.data.url === "string" && event.notification.data.url.startsWith("/") ? event.notification.data.url : "/";
  event.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(list => {
    for (const client of list) { if (new URL(client.url).origin === self.location.origin) { client.navigate(target); return client.focus(); } }
    return self.clients.openWindow(target);
  }));
});
